//
//  MyTableViewController.m
//  AVFoundation
//
//  Created by tao on 16/8/5.
//  Copyright © 2016年 hdu. All rights reserved.
//

#import "MyTableViewController.h"
#import "VViewController.h"
@interface MyTableViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) NSMutableArray *musics;
@property (nonatomic, strong) NSMutableArray *fillPaths;
@end

@implementation MyTableViewController

- (void)viewDidLoad {
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];

    [super viewDidLoad];
    self.tableView.delegate = self;
//    //加载音乐路劲
//    NSFileManager *fm = [NSFileManager defaultManager];
//    NSString *path = @"/Users/tao-pc/Desktop/Music 2";
//    NSArray *paths = [fm contentsOfDirectoryAtPath:path error:nil];
//    for (NSString *path2 in paths) {
//        if ([path2 hasSuffix:@".mp3"]) {
//            [self.fillPaths addObject:[path stringByAppendingPathComponent:path2]];
//            NSLog(@"%@",path2);
//
//        }
//    }
    
    // 歌曲
    _musics = [@[@"薛之谦 - 我好像在哪见过你", @"G.E.M.邓紫棋 - 囚鸟", @"薛之谦 - 我好像在哪见过你"] mutableCopy];
    _fillPaths = [NSMutableArray array];
    for (NSString *musicPath in _musics) {
        NSString *path = [[NSBundle mainBundle] pathForResource:musicPath ofType:@".mp3"];
        [_fillPaths addObject:path];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.fillPaths.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    //取到全路径 并且删除掉扩展名
    cell.textLabel.text = [[self.fillPaths[indexPath.row] lastPathComponent] stringByDeletingPathExtension];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    VViewController *vc = [VViewController sharePlayingVC];
    vc.fillPaths = self.fillPaths;
    vc.index = indexPath.row;
    
    [self.navigationController pushViewController:vc animated:YES];
}


- (NSMutableArray *)fillPaths {
	if(_fillPaths == nil) {
		_fillPaths = [[NSMutableArray alloc] init];
	}
	return _fillPaths;
}


@end
