//
//  ViewController.m
//  BluetoothStubOnIOS
//
//  Created by 刘彦玮 on 15/12/11.
//  Copyright © 2015年 刘彦玮. All rights reserved.
//

#import "ViewController.h"
#import "BabyBluetooth.h"
#import <objc/message.h>
#import "VViewController.h"
#import "MusicManager.h"
//#import <AVFoundation/AVFoundation.h>


@interface ViewController ()<MusicManagerDelegate>{
    BabyBluetooth *baby;
    UILabel *_directionLB;
    UIButton *_directionBtn;
    
    UILabel *_speedLB;
    UISlider *_speedSD;
    UILabel *_speedIndicateLB;
    
    UISlider *_batterySD;
    
    // 歌曲
    UIButton *_musicBtn;
//    UILabel *_musicLB;
    NSMutableArray *_musics;
    NSMutableArray *_fillPaths;

    NSMutableArray *_musicPaths;
    
    BOOL firstPlay;
//    NSInteger _Currentindex;

}

//@property (nonatomic, strong)AVAudioPlayer *player;
@property (nonatomic, strong) NSMutableArray *SubscribedFFF5;
@property (nonatomic, strong) NSMutableArray *SubscribedFFF7;
@property (nonatomic, strong) NSMutableArray *SubscribedFFF3;
@property (nonatomic, strong) VViewController *musicController;

@end

@implementation ViewController

#pragma mark - LifeCircle
- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self getMusicPath];
    // 初始化音乐控制器
    // 歌曲
    firstPlay = NO;
    _musics = [@[@"G.E.M.邓紫棋 - 有多少爱可以重来", @"G.E.M.邓紫棋 - 囚鸟", @"薛之谦 - 我好像在哪见过你"] mutableCopy];
    _fillPaths = [NSMutableArray array];
    for (NSString *musicPath in _musics) {
        NSString *path = [[NSBundle mainBundle] pathForResource:musicPath ofType:@".mp3"];
        [_fillPaths addObject:path];
    }
    [MusicManager shareMusicManager].fillPaths = _fillPaths;
    [MusicManager shareMusicManager].index = 0;
    [MusicManager shareMusicManager].delegate = self;
    
    // 初始化视图
    [self SetupUI];
    
    // 订阅了FFF5数组
    self.SubscribedFFF5 = [NSMutableArray array];
    self.SubscribedFFF7 = [NSMutableArray array];
    self.SubscribedFFF3 = [NSMutableArray array];

    
    //配置第一个服务s1
    CBMutableService *s1 = makeCBService(@"FFF0");
    //配置s1的3个characteristic
    makeCharacteristicToService(s1, @"FFF1", @"r", @"0");//读 电量
    makeCharacteristicToService(s1, @"FFF2", @"rw", @"0");//写 方向显示
    makeCharacteristicToService(s1, genUUID(), @"rw", @"hello3");//读写,自动生成uuid
    makeCharacteristicToService(s1, @"FFF4", @"rwn", @"0");// 读写听 音乐播放
    makeCharacteristicToService(s1, @"FFF5", @"rwn", @"0");//notify字段 速度
    // 音乐
    makeCharacteristicToService(s1, @"FFF6", @"rwn", @"0");// 总的时间
    makeCharacteristicToService(s1, @"FFF7", @"rwn", @"0");//现在时间
    makeCharacteristicToService(s1, @"FFF8", @"rwn", @"0");//音量控制
    makeCharacteristicToService(s1, @"FFF9", @"rwn", @"0");//播放状态
    makeCharacteristicToService(s1, @"FFF3", @"rwn", @"0");//发现障碍


    //配置第一个服务s2
    CBMutableService *s2 = makeCBService(@"FFE0");
    makeStaticCharacteristicToService(s2, genUUID(), @"hello6", [@"a" dataUsingEncoding:NSUTF8StringEncoding]);//一个含初值的字段，该字段权限只能是只读
    //实例化baby
    baby = [BabyBluetooth shareBabyBluetooth];
    //配置委托
    [self babyDelegate];
    //添加服务和启动外设
    baby.bePeripheral().addServices(@[s1,s2]).startAdvertising();
    
    // 歌曲
    _musics = [@[@"薛之谦 - 我好像在哪见过你", @"G.E.M.邓紫棋 - 囚鸟", @"薛之谦 - 我好像在哪见过你"] mutableCopy];
    _musicPaths = [NSMutableArray array];
    for (NSString *musicPath in _musics) {
        NSString *path = [[NSBundle mainBundle] pathForResource:musicPath ofType:@".mp3"];
        [_musicPaths addObject:path];
    }
    
}



#pragma mark - SetupUI
- (void)SetupUI{
    _speedLB = [[UILabel alloc] init];
    _speedLB.text = @"车速";
    _speedLB.font = font(28);
    _speedLB.textColor = [UIColor blueColor];
    _speedLB.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:_speedLB];
    CGRect rect = [_speedLB textRectForBounds:CGRectMake(0, 0, SSize.width, 100) limitedToNumberOfLines:0];

    // 方向标题
    _directionLB = [[UILabel alloc] init];
    _directionLB.text = @"运行方向：";
    _directionLB.font = [UIFont systemFontOfSize:14];
    _directionLB.textColor = [UIColor blueColor];
    CGRect Direrect = [_directionLB textRectForBounds:CGRectMake(0, 0, SSize.width, 100) limitedToNumberOfLines:0];
    [self.view addSubview:_directionLB];
    [_directionLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset = 64;
        make.height.offset = 14;
        make.width.offset = Direrect.size.width;
        make.left.offset = 49 - rect.size.width;
    }];
    
    _directionBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_directionBtn setTitle:@"方向" forState:UIControlStateNormal];
    [_directionBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _directionBtn.titleLabel.font = font(30);
    [self.view addSubview:_directionBtn];
    [_directionBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.offset = 100;
        make.left.equalTo(_directionLB.mas_right).offset = 20;
        make.height.offset = 15;
        make.centerY.equalTo(_directionLB.mas_centerY).offset = 0;
    }];
    
    _speedSD = [[UISlider alloc] init];
    _speedSD.maximumValue = 100;
    _speedSD.minimumValue = 0;
    _speedSD.value = 0;
    [_speedSD addTarget:self action:@selector(changeSpeed:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:_speedSD];
    [_speedSD mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset = 64;
        make.top.equalTo(_directionLB.mas_bottom).offset = 20;
        make.right.offset = -64;
    }];
    

    [_speedLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_speedSD.mas_centerY).offset = 0;
        make.height.offset = 14;
        make.right.equalTo(_speedSD.mas_left).offset = -15;
        make.width.offset = 50;
    }];
    
    _speedIndicateLB = [[UILabel alloc] init];
    _speedIndicateLB.font =  font(28);
    _speedIndicateLB.textColor = [UIColor blackColor];
    _speedIndicateLB.text = @"0 km";
    [self.view addSubview:_speedIndicateLB];
    [_speedIndicateLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.offset = 14;
        make.width.offset = 50;
        make.left.equalTo(_speedSD.mas_right).offset = 8;
        make.centerY.equalTo(_speedSD.mas_centerY).offset = 0;
    }];
    
    _musicBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_musicBtn setTitle:@"发现障碍" forState:UIControlStateNormal];
    [_musicBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _musicBtn.titleLabel.font = font(30);
    [_musicBtn addTarget:self action:@selector(reciveZhangai) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_musicBtn];
    [_musicBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_directionLB.mas_left).offset = 0;
        make.height.offset = 44;
        make.top.equalTo(_speedLB.mas_bottom).offset = 20;
        make.width.offset = 80;
    }];
    
//    _musicLB = [[UILabel alloc] init];
//    _musicLB.font = font(28);
//    _musicLB.textColor = [UIColor blackColor];
//    _musicLB.textAlignment = NSTextAlignmentCenter;
//    _musicLB.text = @"暂停";
//    [self.view addSubview:_musicLB];
//    [_musicLB mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerX.offset = 0;
//        make.height.offset = 14;
//        make.top.equalTo(_speedLB.mas_bottom).offset = 20;
//        make.width.offset = 200;
//    }];
}


// /Users/tao/Desktop/最新/BluetoothStubOnIOS/BluetoothStubOnIOS/Music/G.E.M.邓紫棋 - 有多少爱可以重来.mp3

#pragma mark - 小车控制
- (void)changeSpeed:(UISlider *)slider{
    _speedIndicateLB.text = [NSString stringWithFormat:@"%ld km", (long)slider.value];
    [self changedLocatonSpeed];
}

// 改变本地车速数据 == noti
- (void)changedLocatonSpeed{
    NSMutableArray *services = baby.bePeripheral().services;
    
    if (services.count > 0) {
        for (CBService *service in services) {
            if ([service.UUID.description isEqualToString:@"FFF0"]) {
                for (CBCharacteristic *chara in service.characteristics) {
                    if ([chara.UUID.description isEqualToString:@"FFF5"]) {
                        NSString *speedValue = [NSString stringWithFormat:@"%ld", (long)_speedSD.value];
                        NSLog(@"speedValue ====00000 %@", speedValue);
                        NSData *data = [speedValue dataUsingEncoding:NSUTF8StringEncoding];
                        NSLog(@"speedValue data : %@", data);
                        BabyPeripheralManager *peripheralManager = baby.bePeripheral();
                        CBPeripheralManager *peripheral = peripheralManager.peripheralManager;
                        NSLog(@" ====data%@", data);
                        NSLog(@"====_speedSD.value%f", _speedSD.value);
                        [peripheral updateValue:data forCharacteristic:(CBMutableCharacteristic *)chara onSubscribedCentrals:self.SubscribedFFF5];
                        
                    }else{
                        
                    }
                }
            }
            
        }
    }
    

}

// 改变本地车速数据 == noti
- (void)reciveZhangai{
    NSMutableArray *services = baby.bePeripheral().services;
    
    if (services.count > 0) {
        for (CBService *service in services) {
            if ([service.UUID.description isEqualToString:@"FFF0"]) {
                for (CBCharacteristic *chara in service.characteristics) {
                    if ([chara.UUID.description isEqualToString:@"FFF3"]) {
                        
                        NSInteger i = rand()%100 + 10;
                        NSString *speedValue = [NSString stringWithFormat:@"%d",i];
                        
                        NSLog(@"speedValue ====00000 %@", speedValue);
                        NSData *data = [speedValue dataUsingEncoding:NSUTF8StringEncoding];
                        NSLog(@"speedValue data : %@", data);
                        BabyPeripheralManager *peripheralManager = baby.bePeripheral();
                        CBPeripheralManager *peripheral = peripheralManager.peripheralManager;
                        NSLog(@" ====data%@", data);
                        NSLog(@"====_speedSD.value%f", _speedSD.value);
                        
                        [peripheral updateValue:data forCharacteristic:(CBMutableCharacteristic *)chara onSubscribedCentrals:self.SubscribedFFF3];
                        
                    }else{
                        
                    }
                }
            }
            
        }
    }
    
    
}



// 方向控制
- (void)makeDirectionWithWriteString:(NSString *)string{
    if ([string isEqualToString:@"<01>"]) {
        [_directionBtn setTitle:@"向前" forState:UIControlStateNormal];
    }else if ([string isEqualToString:@"<02>"]){
        [_directionBtn setTitle:@"后退" forState:UIControlStateNormal];
    }else if ([string isEqualToString:@"<03>"]){
        [_directionBtn setTitle:@"向左" forState:UIControlStateNormal];
    }else if ([string isEqualToString:@"<04>"]){
        [_directionBtn setTitle:@"向右" forState:UIControlStateNormal];
    }else if ([string isEqualToString:@"<05>"]){
        [_directionBtn setTitle:@"前进" forState:UIControlStateNormal];
    }else if ([string isEqualToString:@"<06>"]){
        [_directionBtn setTitle:@"停止" forState:UIControlStateNormal];
    }else if ([string isEqualToString:@"<07>"]){
        [_directionBtn setTitle:@"后退" forState:UIControlStateNormal];
    }
}

#pragma mark - Music
// 音乐控制
- (void)controlMusicPlayWithString:(NSString *)string{
    NSLog(@"音乐控制 %@", string);
    if ([string isEqualToString:@"<02>"]) {// 上一首
        //            [_musicController lastMusic];
        [[MusicManager shareMusicManager] lastPlay];
    }else if ([string isEqualToString:@"<05>"]){// 播放
        //            [_musicController playStopMusic];
        [[MusicManager shareMusicManager] StartMusic];
        firstPlay = YES;
        
        
    }else if ([string isEqualToString:@"<06>"]){// 暂停
        //            [_musicController playStopMusic];
        [[MusicManager shareMusicManager] playStop];
        
    }else if ([string isEqualToString:@"<03>"]){// 下一首
        //            [_musicController nextMusic];
        [[MusicManager shareMusicManager] nextPlay];
    }else if ([string containsString:@"7"]){// 循环
        [[MusicManager shareMusicManager] playCurrentMusic];

    }else if ([string containsString:@"8"]){// 随机
        [[MusicManager shareMusicManager] playAnyMusic];

    }
}

- (void)getToMusciController{
//    _musicController = [VViewController sharePlayingVC];
//    _musicController.fillPaths = _musicPaths;
//    _musicController.index = 0;
//    [self presentViewController:_musicController animated:YES completion:nil];
    
    
}

// 写入总的时间
- (void)writeDuration:(NSInteger)duration{
    
}


#pragma mark - MusicManagerDelegate
// 返回现在时间
- (void)ManagerMusicWithDuration:(NSInteger)duration{
    NSLog(@"现在时间%ld", (long)duration);
    if ([MusicManager shareMusicManager].player.isPlaying) {
        NSMutableArray *services = baby.bePeripheral().services;
        if (services.count > 0) {
            for (CBService *service in services) {
                if ([service.UUID.description isEqualToString:@"FFF0"]) {
                    for (CBCharacteristic *chara in service.characteristics) {
                        if ([chara.UUID.description isEqualToString:@"FFF7"]) {
                            NSString *value = [NSString stringWithFormat:@"%ld", (long)duration];
                            NSLog(@"speedValue ====00000 %@", value);
                            NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
                            NSLog(@"speedValue data : %@", data);
                            BabyPeripheralManager *peripheralManager = baby.bePeripheral();
                            CBPeripheralManager *peripheral = peripheralManager.peripheralManager;
                            NSLog(@" ====data%@", data);
                            NSLog(@"====_speedSD.value%f", _speedSD.value);
                            [peripheral updateValue:data forCharacteristic:(CBMutableCharacteristic *)chara onSubscribedCentrals:self.SubscribedFFF7];
                            
                        }else{
                            
                        }
                    }
                }
                
            }
        }
    }
    
    
}



//// 返回播放状态
//- (void)getBackForPlayingState{
//    if ([MusicManager shareMusicManager].player.isPlaying) {
//        NSMutableArray *services = baby.bePeripheral().services;
//        if (services.count > 0) {
//            for (CBService *service in services) {
//                if ([service.UUID.description isEqualToString:@"FFF0"]) {
//                    for (CBCharacteristic *chara in service.characteristics) {
//                        if ([chara.UUID.description isEqualToString:@"FFF9"]) {
//                            
//                            NSInteger state;
//                            if ([MusicManager shareMusicManager].player.isPlaying) {
//                                state = 1;
//                            }else{
//                                state = 0;
//                            }
//                            
//                            NSString *value = [NSString stringWithFormat:@"%ld", (long)state];
//                            NSLog(@"speedValue ====00000 %@", value);
//                            NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
//                            NSLog(@"speedValue data : %@", data);
//                            BabyPeripheralManager *peripheralManager = baby.bePeripheral();
//                            CBPeripheralManager *peripheral = peripheralManager.peripheralManager;
//                            NSLog(@" ====data%@", data);
//                            NSLog(@"====_speedSD.value%f", _speedSD.value);
//                            
//                            [peripheral updateValue:data forCharacteristic:(CBMutableCharacteristic *)chara onSubscribedCentrals:self.SubscribedFFF7];
//                            
//                        }else{
//                            
//                        }
//                    }
//                }
//                
//            }
//        }
//    }
//}




#pragma mark - babyDelegate
//配置委托
- (void)babyDelegate{

    //设置添加service委托 | set didAddService block
    [baby peripheralModelBlockOnPeripheralManagerDidUpdateState:^(CBPeripheralManager *peripheral) {
        NSLog(@"PeripheralManager trun status code: %ld",(long)peripheral.state);
    }];
    
    //设置添加service委托 | set didAddService block
    [baby peripheralModelBlockOnDidStartAdvertising:^(CBPeripheralManager *peripheral, NSError *error) {
        NSLog(@"didStartAdvertising !!!");
    }];
    
    //设置添加service委托 | set didAddService block
    [baby peripheralModelBlockOnDidAddService:^(CBPeripheralManager *peripheral, CBService *service, NSError *error) {
        NSLog(@"Did Add Service uuid: %@ ",service.UUID);
    }];
    
    // read 试试UPDATA *****8
    //设置添加service委托 | set didAddService block
    
    
    [baby peripheralModelBlockOnDidReceiveReadRequest:^(CBPeripheralManager *peripheral,CBATTRequest *request) {
        NSLog(@"request characteristic uuid:%@",request.characteristic.UUID);
        //判断是否有读数据的权限
        if (request.characteristic.properties & CBCharacteristicPropertyRead) {

            NSData *data = request.characteristic.value;

            // 读取电量，并将电量保存下来
            if ([request.characteristic.UUID.description isEqualToString:@"FFF1"]) {
                
                int i = [self getCurrentBatteryLevel];
                NSString *string = [NSString stringWithFormat:@"%d", i];
                string = [string stringByReplacingOccurrencesOfString:@"%" withString:@""];
                
                NSLog(@"%@", string);
                NSLog(@"speedValue data : %@", data);
                
                NSData *dataa = [string dataUsingEncoding:NSUTF8StringEncoding];
                NSLog(@"dataa :%@", dataa);
                [request setValue:dataa];
                
                [peripheral updateValue:dataa forCharacteristic:(CBMutableCharacteristic *)request.characteristic onSubscribedCentrals:nil];
                
                
            }
            
            
            // 读取音乐总的时间
            if ([request.characteristic.UUID.description isEqualToString:@"FFF6"]) {
                
                NSInteger i = [[MusicManager shareMusicManager] getMusicTime];
                
                NSString *string = [NSString stringWithFormat:@"%ld", (long)i];

                NSLog(@"%@", string);
                NSData *dataa = [string dataUsingEncoding:NSUTF8StringEncoding];
                NSLog(@"dataa :%@", dataa);
                [request setValue:dataa];
                [peripheral updateValue:dataa forCharacteristic:(CBMutableCharacteristic *)request.characteristic onSubscribedCentrals:nil];
                
            }
            
            // getBackForPlayingState
            // 读取音乐总状态
            if ([request.characteristic.UUID.description isEqualToString:@"FFF9"]) {
            
                NSInteger state;
                if ([MusicManager shareMusicManager].player.isPlaying) {
                    state = 1;
                }else{
                    state = 0;
                }
                
                NSString *value = [NSString stringWithFormat:@"%ld", (long)state];
                NSLog(@"speedValue ====00000 %@", value);
                NSData *dataa = [value dataUsingEncoding:NSUTF8StringEncoding];
                
                [request setValue:dataa];
                [peripheral updateValue:dataa forCharacteristic:(CBMutableCharacteristic *)request.characteristic onSubscribedCentrals:nil];
                
            }
            
            // 读取音乐音量
            // getBackForPlayingState
            // 读取音乐总的时间
            if ([request.characteristic.UUID.description isEqualToString:@"FFF8"]) {
                
                CGFloat state = [[MusicManager shareMusicManager] getMusicVoice];
                
                NSString *value = [NSString stringWithFormat:@"%f", state];
                NSLog(@"speedValue ====00000 %@", value);
                NSData *dataa = [value dataUsingEncoding:NSUTF8StringEncoding];
                
                [request setValue:dataa];
                [peripheral updateValue:dataa forCharacteristic:(CBMutableCharacteristic *)request.characteristic onSubscribedCentrals:nil];
                
            }
            
            
            //对请求作出成功响应
            [peripheral respondToRequest:request withResult:CBATTErrorSuccess];
            

            
        }else{
            //错误的响应
            [peripheral respondToRequest:request withResult:CBATTErrorWriteNotPermitted];
        }
    }];
    
    
    // write
    //设置添加service委托 | set didAddService block
    [baby peripheralModelBlockOnDidReceiveWriteRequests:^(CBPeripheralManager *peripheral,NSArray *requests) {
        NSLog(@"didReceiveWriteRequests");
        CBATTRequest *request = requests[0];
        //判断是否有写数据的权限
        if (request.characteristic.properties & CBCharacteristicPropertyWrite) {
            //需要转换成CBMutableCharacteristic对象才能进行写值
            CBMutableCharacteristic *c =(CBMutableCharacteristic *)request.characteristic;
            c.value = request.value;
            [peripheral respondToRequest:request withResult:CBATTErrorSuccess];
            
            // 写入方向
            if ([c.UUID.description isEqualToString:@"FFF2"]) {
                [self makeDirectionWithWriteString:[NSString stringWithFormat:@"%@", c.value]];
                NSLog(@"%@", c.value);
                NSLog(@"%@", [NSString stringWithFormat:@"%@", c.value]);
            }
            
            // 写入音乐控制
            if ([c.UUID.description isEqualToString:@"FFF4"]) {
                
                [self controlMusicPlayWithString:[NSString stringWithFormat:@"%@", c.value]];
                NSLog(@"方向控制%@", [NSString stringWithFormat:@"%@", c.value]);
                
            }
            
            // 写入音乐时间
            if ([c.UUID.description isEqualToString:@"FFF7"]) {
                
//                [self controlMusicPlayWithString:[NSString stringWithFormat:@"%@", c.value]];
                NSLog(@"音乐控制%@", [NSString stringWithFormat:@"%@", c.value]);
                NSString *str = [[NSString alloc] initWithData:c.value encoding:NSUTF8StringEncoding];
                str = [str stringByReplacingOccurrencesOfString:@"<" withString:@""];
                str = [str stringByReplacingOccurrencesOfString:@">" withString:@""];
                [[MusicManager shareMusicManager] musciCurrentTimeControl:[str integerValue]];
                
            }
            
            
            // 
            if ([c.UUID.description isEqualToString:@"FFF8"]) {
                
//                [self controlMusicPlayWithString:[NSString stringWithFormat:@"%@", c.value]];
                NSLog(@"音乐控制%@", [NSString stringWithFormat:@"%@", c.value]);
                NSString *str = [[NSString alloc] initWithData:c.value encoding:NSUTF8StringEncoding];
                str = [str stringByReplacingOccurrencesOfString:@"<" withString:@""];
                str = [str stringByReplacingOccurrencesOfString:@">" withString:@""];
                [[MusicManager shareMusicManager] musicVoiceControl:[str floatValue]];
                
            }
            
        }
        else{
            [peripheral respondToRequest:request withResult:CBATTErrorWriteNotPermitted];
        }
        
    }];
    
    // noti
//    __block NSTimer *timer;
    //设置添加service委托 | set didAddService block
    [baby peripheralModelBlockOnDidSubscribeToCharacteristic:^(CBPeripheralManager *peripheral, CBCentral *central, CBCharacteristic *characteristic) {
        if ([characteristic.UUID.description isEqualToString:@"FFF5"]) {
            
            
            if (![self.SubscribedFFF5 containsObject:central]) {
                [self.SubscribedFFF5 addObject:central];
            }
            if ([self.SubscribedFFF7 containsObject:central]) {
                [self.SubscribedFFF7 addObject:central];
            }
            
            if ([self.SubscribedFFF3 containsObject:central]) {
                [self.SubscribedFFF3 addObject:central];
            }
            
        }
        NSLog(@"订阅了 %@的数据",characteristic.UUID);
        //每秒执行一次给主设备发送一个当前时间的秒数
//        timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(sendData:) userInfo:characteristic  repeats:YES];
    }];
    
    //设置添加service委托 | set didAddService block
    [baby peripheralModelBlockOnDidUnSubscribeToCharacteristic:^(CBPeripheralManager *peripheral, CBCentral *central, CBCharacteristic *characteristic) {
        NSLog(@"peripheralManagerIsReadyToUpdateSubscribers");
//        [timer fireDate];
    }];
    
}

//发送数据，发送当前时间的秒数
-(BOOL)sendData:(NSTimer *)t {
    CBMutableCharacteristic *characteristic = t.userInfo;
    NSDateFormatter *dft = [[NSDateFormatter alloc]init];
    [dft setDateFormat:@"ss"];
//    NSLog(@"%@",[dft stringFromDate:[NSDate date]]);
    //执行回应Central通知数据
    return  [baby.peripheralManager updateValue:[[dft stringFromDate:[NSDate date]] dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:(CBMutableCharacteristic *)characteristic onSubscribedCentrals:nil];
}


#pragma mark - 电池电量
- (int)getCurrentBatteryLevel

{
    
    UIApplication *app = [UIApplication sharedApplication];
    
    if (app.applicationState == UIApplicationStateActive||app.applicationState==UIApplicationStateInactive) {
        
        Ivar ivar=  class_getInstanceVariable([app class],"_statusBar");
        
        id status  = object_getIvar(app, ivar);
        
        for (id aview in [status subviews]) {
            
            int batteryLevel = 0;
            
            for (id bview in [aview subviews]) {
                
                if ([NSStringFromClass([bview class]) caseInsensitiveCompare:@"UIStatusBarBatteryItemView"] == NSOrderedSame&&[[[UIDevice currentDevice] systemVersion] floatValue] >=6.0){
                    
                    Ivar ivar=  class_getInstanceVariable([bview class],"_capacity");
                    
                    if(ivar){
                        
                        batteryLevel = ((int (*)(id, Ivar))object_getIvar)(bview, ivar);
                        
                        //这种方式也可以
                        
                        /*ptrdiff_t offset = ivar_getOffset(ivar);
                         
                         unsigned char *stuffBytes = (unsigned char *)(__bridge void *)bview;
                         
                         batteryLevel = * ((int *)(stuffBytes + offset));*/
                        
                        NSLog(@"电池电量:%d",batteryLevel);
                        
                        if (batteryLevel > 0 && batteryLevel <= 100) {
                            
                            return batteryLevel;
                            
                        } else {
                            
                            return 0;
                            
                        }
                        
                    }
                    
                }
                
            }
            
        }
        
    }
    
    return 0;
    
}

// 进制转换
- (NSString *)getHexByDecimal:(NSInteger)decimal {
    
    NSString *hex =@"";
    NSString *letter;
    NSInteger number;
    for (int i = 0; i<9; i++) {
        
        number = decimal % 16;
        decimal = decimal / 16;
        switch (number) {
                
            case 10:
                letter =@"A"; break;
            case 11:
                letter =@"B"; break;
            case 12:
                letter =@"C"; break;
            case 13:
                letter =@"D"; break;
            case 14:
                letter =@"E"; break;
            case 15:
                letter =@"F"; break;
            default:
                letter = [NSString stringWithFormat:@"%ld", (long)number];
        }
        hex = [letter stringByAppendingString:hex];
        if (decimal == 0) {
            
            break;
        }
    }
    return hex;
}




@end
