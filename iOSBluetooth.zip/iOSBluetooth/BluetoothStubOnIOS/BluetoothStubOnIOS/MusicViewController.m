//
//  MusicViewController.m
//  BluetoothStubOnIOS
//
//  Created by tao on 2017/5/20.
//  Copyright © 2017年 刘彦玮. All rights reserved.
//

#import "MusicViewController.h"
#import "Utils.h"
#import <AVFoundation/AVFoundation.h>
@interface MusicViewController ()<AVAudioPlayerDelegate, UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) NSDictionary *lrcDic;

// 现在时间
@property (nonatomic, strong) UILabel *currentLabel;
// 总的时间
@property (nonatomic, strong) UILabel *durationLabel;
// 播放
@property (nonatomic, strong) UIButton *btn;
// 进度
@property (nonatomic, strong) UISlider *slider;
// 声音
@property (nonatomic, strong) UISlider *volumSlider;
// 上一曲
@property (nonatomic, strong) UIButton *lastBtn;
// 下一曲
@property (nonatomic, strong) UIButton *nextBtn;


// 选择
@property (nonatomic, strong) UISegmentedControl *segment;
// 背景图
@property (nonatomic, strong) UIImageView *imageView;
// 歌词
@property (nonatomic, strong) UITableView *tableview;

@property (nonatomic, strong) AVAudioPlayer *player;
@property (nonatomic, strong) NSString *currentPath;
@property (nonatomic, strong) NSTimer *timer;


@end

@implementation MusicViewController


- (void)setupUI{
    // 播放
    _btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btn setTitle:@"播放" forState:UIControlStateNormal];
    [_btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _btn.titleLabel.font = font(realWidth(28));
    [_btn setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:_btn];
    [_btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.offset = 0;
        make.width.offset = realWidth(100);
        make.height.offset = realWidth(44);
        make.bottom.offset = realWidth(30);
    }];
    
    // 现在时间
    _currentLabel = [[UILabel alloc] init];
    _currentLabel.text = @"0";
    _currentLabel.textColor = [UIColor blackColor];
    _currentLabel.font = font(realWidth(28));
    [self.view addSubview:_currentLabel];
    [_currentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset = realWidth(8);
        make.width.offset = realWidth(50);
        make.top.equalTo(_btn.mas_top).offset = 0;
        make.height.offset = realWidth(14);
    }];
    
    //总的时间
    _durationLabel = [[UILabel alloc] init];
    _durationLabel.text = @"0";
    _durationLabel.textColor = [UIColor blackColor];
    _durationLabel.font = font(realWidth(28));
    [self.view addSubview:_durationLabel];
    [_durationLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset = realWidth(-8);
        make.width.offset = realWidth(50);
        make.top.equalTo(_btn.mas_top).offset = 0;
        make.height.offset = realWidth(14);
    }];
    
    // 进度
    _slider = [[UISlider alloc] init];
    _slider.value = 0;
    _slider.minimumValue = 0;
    [self.view addSubview:_slider];
    [_slider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset = realWidth(8);
        make.right.offset = realWidth(-8);
        make.bottom.equalTo(_currentLabel.mas_top).offset = realWidth(-15);
    }];
    
    // 音量
    
    
    // 上一曲
//    _lastBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [_lastBtn setTitle:@"上一曲" forState:UIControlStateNormal];
//    [_lastBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
//    _lastBtn.titleLabel.font = font(28);
//    CGRect rect = [_lastBtn.titleLabel textRectForBounds:CGRectMake(0, 0, SSize.width, 100) limitedToNumberOfLines:0];
//    [self.view addSubview:_lastBtn];
//    [_lastBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.width.offset = rect.size.width;
//        make.height.offset = rect.size.height;
//        make.left.offset = 8;
//        make.bottom.equalTo
//    }];
    
}

+ (MusicViewController *)sharePlayingVC
{
    static MusicViewController *instance;
    static dispatch_once_t onceToken;
    // onceToken默认等于0, 如果是0就会执行block, 如果不是0就不会执行
    NSLog(@"%ld", onceToken);
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

#pragma mark -生命周期 Life Circle
- (void)viewDidLoad {
    [self.tableview registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [super viewDidLoad];
    CALayer *layer = self.btn.layer;
    layer.cornerRadius = 10;
    [self.btn setTitle:@"暂停" forState:UIControlStateNormal];
    [self.btn setBackgroundImage:[UIImage imageNamed:@"1"] forState:UIControlStateHighlighted];
    
    [self setupUI];
}



//页面将要出现
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self playMusic];
    //页面将要出现的时候加载 timer 页面消失的时候释放 timer
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(getCurrentTime) userInfo:nil repeats:YES];
}
- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.timer invalidate];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 方法 method
//加载音乐
- (void)playMusic{
    if (self.index == -1) {
        self.index = self.fillPaths.count - 1;
    }
    if (self.index == self.fillPaths.count) {
        self.index = 0;
    }
    //播放一首歌的时候将标题加入
    self.title = [[self.fillPaths[self.index] lastPathComponent] stringByDeletingPathExtension];
    //播放 暂停
    self.currentPath = self.fillPaths[self.index];
    
    //提曲歌名
    NSDictionary *musicInfo = [Utils getMusicInfoByPath:self.currentPath];
    self.title = musicInfo[@"title"];
    NSData *data = musicInfo[@"artwork"];
    self.imageView.image = [UIImage imageWithData:data];
    //判断当前播放的和即将播放的是否是同一首歌曲
    if (![self.player.url.path isEqualToString:self.currentPath]){
        self.player = [[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL fileURLWithPath:self.currentPath] error:nil];
    }
    self.player.delegate = self;
    //    self.player = [[AVAudioPlayer alloc]initWithData:[NSData dataWithContentsOfFile:self.currentPath] error:nil];
    
    [self.player play];
    self.player.volume = .5;
    //总时长加载到 label 上
    self.slider.maximumValue = (NSInteger)self.player.duration;
    self.durationLabel.text = [NSString stringWithFormat:@"%d:%d",(int)self.slider.maximumValue/60, (int)self.slider.maximumValue % 60];
    NSString *lrcPath = [self.currentPath stringByReplacingOccurrencesOfString:@"mp3" withString:@"lrc"];
    //加载歌词
    if ([[NSFileManager defaultManager]fileExistsAtPath:lrcPath]) {
        self.lrcDic = [Utils parseLrcWithPath:lrcPath];
        [self.tableview reloadData];
        self.tableview.hidden = NO;
    }else{
        self.tableview.hidden = YES;
    }
}
//显示现在和总的时间
- (void)getCurrentTime{
    self.slider.value = (NSInteger)self.player.currentTime;
    self.currentLabel.text = [NSString stringWithFormat:@"%d:%d",(int)self.slider.value/60, (int)self.slider.value%60];
    //同步歌词
    
    NSArray *keys = [self.lrcDic.allKeys sortedArrayUsingSelector:@selector(compare:)];
    for (int i = 1; i < keys.count; i++) {
        float time = [keys[i] floatValue];
        if (time > self.player.currentTime) {
            int row = i - 1;
            [self.tableview selectRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            break;
        }
    }
    
    
    
}
//得到 slider 的value
- (IBAction)changed:(UISlider *)sender {
    self.player.currentTime = self.slider.value;
}
//上一曲
- (IBAction)clickedLeftBtn:(UIButton *)sender {
    self.index--;
    if (self.segment.selectedSegmentIndex == 2) {
        self.index = arc4random() % self.fillPaths.count;
    }
    [self playMusic];
}
//下一曲
- (IBAction)clickRightBtn:(UIButton *)sender {
    self.index++;
    if (self.segment.selectedSegmentIndex == 2) {
        self.index = arc4random() % self.fillPaths.count;
    }
    [self playMusic];
}
//slider
- (IBAction)volumChange:(UISlider *)sender {
    self.player.volume = self.volumSlider.value;
}

#pragma mark -外部控制
// 上一曲
- (void)lastMusic{
    [self clickedLeftBtn:nil];
}
// 下一曲
- (void)nextMusic{
    [self clickRightBtn:nil];
}
// 播放、暂停
- (void)playStopMusic{
    [self clicked:nil];
}

//点击播放暂停
- (IBAction)clicked:(id)sender {
    if (self.player.isPlaying) {
        [self.player pause];
        [self.btn setTitle:@"播放" forState:UIControlStateNormal];
    }else{
        [self.player play];
        [self.btn setTitle:@"暂停" forState:UIControlStateNormal];
        
    }
}


#pragma mark - AVAudio Delegate
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    switch (self.segment.selectedSegmentIndex) {
        case 0://顺序播放
            self.index++;
            [self playMusic];
            
            break;
            
        case 1://单曲循环
            
            [self playMusic];
            
            break;
        case 2://随机
            self.index = arc4random()%self.fillPaths.count;
            [self playMusic];
            
            break;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.lrcDic.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSArray *keys = [self.lrcDic.allKeys sortedArrayUsingSelector:@selector(compare:)];
    NSNumber *timeKey = keys[indexPath.row];
    cell.textLabel.text = self.lrcDic[timeKey];
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.selectedBackgroundView = [[UIView alloc]initWithFrame:cell.bounds];
    cell.selectedBackgroundView.backgroundColor = [UIColor clearColor];
    cell.textLabel.highlightedTextColor = [UIColor redColor];
    
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 25;
}

@end
