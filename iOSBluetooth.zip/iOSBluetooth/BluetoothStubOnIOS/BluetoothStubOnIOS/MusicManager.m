//
//  MusicManager.m
//  BluetoothStubOnIOS
//
//  Created by tao on 17/5/24.
//  Copyright © 2017年 刘彦玮. All rights reserved.
//

#import "MusicManager.h"

@interface MusicManager ()
@property (nonatomic, strong) NSString *currentPath;
@property (nonatomic, strong) NSTimer *timer;

@end

static MusicManager *_musicManager;

@implementation MusicManager

+ (MusicManager *)shareMusicManager{
    if (!_musicManager) {
        _musicManager = [[MusicManager alloc] init];

    }
    return _musicManager;
}

- (void)StartMusic{
    
    [self playMusicWithNew:NO];
//    [_timer invalidate];
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(getCurrentTime) userInfo:nil repeats:YES];

    }

    //页面将要出现的时候加载 timer 页面消失的时候释放 timer
//    [self.timer invalidate];
    
//    int flags =NSKeyValueObservingOptionNew;
//    [self.player addObserver:self forKeyPath:@"currentTime" options:flags context:nil];
}

// 监听焦距发生改变
//-(void)observeValueForKeyPath:(NSString*)keyPath ofObject:(id)object change:(NSDictionary*)change context:(void*)context {
//    
//    if([keyPath isEqualToString:@"currentTime"]){
//        NSInteger duration =[[change objectForKey:NSKeyValueChangeNewKey] integerValue];
//        NSLog(@"adjustingFocus%ld", (long)duration);
//        [self callBackDuration:duration];
//        
//        // 0代表焦距不发生改变 1代表焦距改变
//        
//    }
//}

- (void)endMusic{
//    [self.timer invalidate];

}

#pragma mark - 方法 method
//加载音乐
- (void)playMusicWithNew:(BOOL)new{
    if (self.player) {
        if (new) {
            [self playWithNew];
        }else{
            [self.player play];
        }
        
    }else{
        [self playWithNew];
        
    }
    
    

}
- (void)playWithNew{
    if (self.index == -1) {
        self.index = self.fillPaths.count - 1;
    }
    if (self.index == self.fillPaths.count) {
        self.index = 0;
    }
    //播放一首歌的时候将标题加入
    //    self.title = [[self.fillPaths[self.index] lastPathComponent] stringByDeletingPathExtension];
    //播放 暂停
    self.currentPath = self.fillPaths[self.index];
    
    //判断当前播放的和即将播放的是否是同一首歌曲
    if (![self.player.url.path isEqualToString:self.currentPath]){
        self.player = [[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL fileURLWithPath:self.currentPath] error:nil];
    }
    self.player.delegate = self;
    self.player = [[AVAudioPlayer alloc]initWithData:[NSData dataWithContentsOfFile:self.currentPath] error:nil];
    
    [self.player play];
    self.player.volume = .5;

}



//显示现在和总的时间
- (void)getCurrentTime{
    
//    if (self.player.duration - self.player.currentTime < 0.55 ) {
//        [self playNextMusic];
//    }
    [self callBackDuration:self.player.currentTime];
//    self.slider.value = (NSInteger)self.player.currentTime;
//    self.currentLabel.text = [NSString stringWithFormat:@"%d:%d",(int)self.slider.value/60, (int)self.slider.value%60];
//    //同步歌词
//    
//    NSArray *keys = [self.lrcDic.allKeys sortedArrayUsingSelector:@selector(compare:)];
//    for (int i = 1; i < keys.count; i++) {
//        float time = [keys[i] floatValue];
//        if (time > self.player.currentTime) {
//            int row = i - 1;
//            [self.tableview selectRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
//            break;
//        }
//    }
    
}

#pragma mark -MusicControl
- (void)playStop{
    if (self.player.isPlaying) {
        [self.player pause];
    }else{
        [self.player play];
    }
}
- (void)nextPlay{
    if (self.index==2) {
        self.index = 0;
    }else{
        self.index++;
    }
    [self playMusicWithNew:YES];
}
- (void)lastPlay{
    if (self.index == 0) {
        self.index = 2;
    }else{
        self.index--;
    }

    [self playMusicWithNew:YES];
}

- (void)playCurrentMusic{
    [self playMusicWithNew:YES];
}
- (void)playAnyMusic{
    _index =  random() % 3;
    [self playMusicWithNew:YES];
}


- (void)playNextMusic{
    if (self.index==2) {
        self.index = 0;
    }else{
        self.index++;
    }
    [self playMusicWithNew:YES];
}
#pragma mark - AVAudio Delegate
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    if (self.index==2) {
        self.index = 0;
    }else{
        self.index++;
    }
    [self playMusicWithNew:YES];
}

#pragma mark - 代理返回

- (NSInteger)getMusicTime{
    if (self.player) {
        if (self.player.duration > 0) {
            return self.player.duration;
        }
    }
    return 0;
}

- (NSInteger)getMusicCurrentTime{
    if (self.player) {
        return self.player.currentTime;
    }
    return 0;
}

- (CGFloat)getMusicVoice{
    if (self.player) {
        NSLog(@"%f", self.player.volume);

        return self.player.volume;
    }
    return 0;
}


- (void)musciCurrentTimeControl:(NSInteger)currentTime{
    if (self.player) {
        if (self.player.duration>=currentTime) {
            self.player.currentTime = currentTime;
        }
    }
}

- (void)musicVoiceControl:(CGFloat)voice{
    if (self.player) {
//        if (self.player.volume) {
//            if (0<voice <1) {
                self.player.volume = voice;
//            }
//        }
    }
}

#pragma mark - Delegate
// 返回现在时间
- (void)callBackDuration:(NSInteger)duration{
    [self.delegate ManagerMusicWithDuration:duration];
}



@end
