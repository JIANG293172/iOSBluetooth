//
//  MusicManager.h
//  BluetoothStubOnIOS
//
//  Created by tao on 17/5/24.
//  Copyright © 2017年 刘彦玮. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@protocol MusicManagerDelegate <NSObject>

- (void)ManagerMusicWithDuration:(NSInteger)duration;


@end

@interface MusicManager : NSObject<AVAudioPlayerDelegate>

@property (nonatomic, assign) NSInteger index;
@property (nonatomic, assign) NSInteger lastIndex;
@property (nonatomic, strong) NSMutableArray *fillPaths;
@property (nonatomic, weak) id<MusicManagerDelegate> delegate;
@property (nonatomic, strong) AVAudioPlayer *player;

+ (MusicManager *)shareMusicManager;


- (void)playStop;
- (void)lastPlay;
- (void)nextPlay;

- (void)playCurrentMusic;
- (void)playAnyMusic;

- (void)StartMusic;
- (void)endMusic;


- (NSInteger)getMusicTime;

- (NSInteger)getMusicCurrentTime;

- (CGFloat)getMusicVoice;

- (void)musciCurrentTimeControl:(NSInteger)currentTime;

- (void)musicVoiceControl:(CGFloat)voice;
@end
