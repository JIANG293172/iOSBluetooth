//
//  UILabel+LeftTopAlign.h
//  bilibili
//
//  Created by tao on 16/7/14.
//  Copyright © 2016年 tao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (LeftTopAlign)//不通用(不适用一般情况)
- (void) textLeftTopAlign;
@end