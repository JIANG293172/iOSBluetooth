//
//  ValueConversion.h
//  bilibili
//
//  Created by tao on 2016/8/6.
//  Copyright © 2016年 tao. All rights reserved.
//

#import <Foundation/Foundation.h>


NSInteger IntegerLength(NSInteger integer);

NSString *IntegerToTenThousand(NSInteger integer);
