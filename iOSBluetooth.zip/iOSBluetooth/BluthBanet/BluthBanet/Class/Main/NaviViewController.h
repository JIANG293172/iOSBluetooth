//
//  NaviViewController.h
//  WWClientOs
//
//  Created by tao on 16/11/15.
//  Copyright © 2016年 tao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NaviViewController : UINavigationController

@end
