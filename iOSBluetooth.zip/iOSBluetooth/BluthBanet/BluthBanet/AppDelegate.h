//
//  AppDelegate.h
//  BluthBanet
//
//  Created by tao on 17/3/24.
//  Copyright © 2017年 tao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

